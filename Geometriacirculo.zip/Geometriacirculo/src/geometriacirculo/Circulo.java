/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometriacirculo;

/**
 *
 * @author Propietario
 */
//Aquí implementamos lo que tenemos en FiguraCirculo.java con el implements
public class Circulo implements FiguraCirculo
{
   private double radio;
    private double areaRadio;
    private double perimetro;
    //Aqui ponemos el valor de pi 
    static final double pi = 3.1415;
//Ponemos el radio:
    public Circulo(double radio) 
    {
        this.radio = radio;
    }
//Nos devuelven el valor del radio:
    public double getRadio() 
    {
        return radio;
    }

    public void setRadio(double radio) 
    {
        this.radio = radio;
    }
//Aqui nos devuelve el valor del area del radio:
    public double getAreaRadio() 
    {
        return areaRadio;
    }
      public double getperimetro() 
    {
        return perimetro;
    }
/*Y por último ponemos la formula del area que es pi * radio al cuadrado pero 
    como no se puede elevar un número lo multiplicamos dos veces:
    */
   
    @Override
    public void area() 
    {
        areaRadio = pi * radio * radio;
    }  
     public void perimetro()
    {
    perimetro = 2* pi *radio;
    }
}
   
