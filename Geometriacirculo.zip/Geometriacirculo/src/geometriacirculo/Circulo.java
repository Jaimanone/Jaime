/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometriacirculo;

/**
 *
 * @author Propietario
 */
//Aquí implementamos lo que tenemos en FiguraCirculo.java con el implements
public class Circulo implements FiguraCirculo
{
    /*Estamos metiendo los private double de radio, del area y del perímetro del
    círculo:
    */
    private double radio;
    private double areaRadio;
    private double perimetro;
    //Aqui ponemos el valor de pi 
    static final double pi = 3.1415;
//Ponemos el radio:
    public Circulo(double radio) 
    {
        this.radio = radio;
    }
//Nos devuelven el valor del radio con el método get y set:
    public double getRadio() 
    {
        return radio;
    }

    public void setRadio(double radio) 
    {
        this.radio = radio;
    }
//Aqui nos devuelve el valor del area del radio con el método get:
    public double getAreaRadio() 
    {
        return areaRadio;
    }
      public double getperimetro() 
    {
        return perimetro;
    }
/*Y por último ponemos la formula del area que es pi * radio al cuadrado pero 
    como no se puede elevar un número lo multiplicamos dos veces y también 
    ponemos la fórmula del perímetro del círculo que es 2 * pi * radio:
    */
   
    @Override
    public void area() 
    {
        areaRadio = pi * radio * radio;
    }  
     public void perimetro()
    {
    perimetro = 2* pi *radio;
    }
}
   
