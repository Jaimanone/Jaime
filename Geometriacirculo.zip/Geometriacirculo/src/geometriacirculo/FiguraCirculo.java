/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometriacirculo;

/**
 *
 * @author Propietario
 */
/*Aqui estamos creando una interfaz llamada FiguraCirculo donde estamos metiendo
dos void que nos permiten después poder realizar los cálculos del área y del
perímetro del círculo:
*/
public interface FiguraCirculo {
    void area();
    void perimetro();
}
